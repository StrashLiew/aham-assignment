from flask import Flask,request, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
CORS(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
db = SQLAlchemy(app)

class Customer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.Text, nullable=False, unique=True)
    phone_no = db.Column(db.String(15), nullable=False, unique=True)
    address = db.Column(db.Text, nullable=False)
    
    def __repr__(self):
        return f"Customer('{self.first_name}', '{self.last_name}', '{self.email}', '{self.phone_no}', '{self.address}')"

@app.route('/')
def index():
    return 'Welcome to Customer Service!'

#Create a customer
@app.route('/customer', methods=['POST'])
def add_customer():
    try:
        customer_data = request.get_json()
        new_customer = Customer(first_name=customer_data['first_name'], last_name=customer_data['last_name'], email=customer_data['email'], phone_no=customer_data['phone_no'], address=customer_data['address'])
        db.session.add(new_customer)
        db.session.commit()
        return jsonify({"message": "Customer added successfully!"})
    except Exception as e:
        return jsonify({'error': str(e)})

#Retrieve all customer
@app.route('/customers', methods=['GET'])
def get_all_customer():
    try:
        customer_list = Customer.query.all()
        
        response = []
        for customer in customer_list:
            customer_data = {
                'id': customer.id,
                'first_name': customer.first_name,
                'last_name': customer.last_name,
                'email': customer.email,
                'phone_no': customer.phone_no,
                'address': customer.address
            }
            response.append(customer_data)
        return jsonify({'customers': response})
    except Exception as e:
        return jsonify({'error': str(e)})
    
#Retrieve a customer by id  
@app.route('/customer/<int:id>', methods=['GET'])
def get_customer_by_id(id):
    try:
        customer = Customer.query.get_or_404(id)
        customer_data = {
            'id': customer.id,
            'first_name': customer.first_name,
            'last_name': customer.last_name,
            'email': customer.email,
            'phone_no': customer.phone_no,
            'address': customer.address
        }
        return jsonify(customer_data)
    except Exception as e:
        return jsonify({'error': str(e)})

#Update a customer by id
@app.route('/customer/<int:id>', methods=['PUT'])
def update_customer_by_id(id):
    try:
        customer = Customer.query.get_or_404(id)
        customer_data = request.get_json()
        
        customer.first_name = customer_data['first_name']
        customer.last_name = customer_data['last_name']
        customer.email = customer_data['email']
        customer.phone_no = customer_data['phone_no']
        customer.address = customer_data['address']
        db.session.commit()
        return jsonify({"message": "Customer updated successfully!"})
    except Exception as e:
        return jsonify({'error': str(e)})
        

#Delete a customer by id
@app.route('/customer/<int:id>', methods=['DELETE'])
def delete_customer_by_id(id):
    try:
        customer = Customer.query.get_or_404(id)
        db.session.delete(customer)
        db.session.commit()
        return jsonify({"message": "Customer deleted successfully!"})
    except Exception as e:
        return jsonify({'error': str(e)})
